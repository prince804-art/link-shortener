import { useState } from 'react';

export default function Home() {
  const [url, setUrl] = useState('');
  const [shortUrl, setShortUrl] = useState('');

  const createShortLink = async () => {
    const res = await fetch('/api/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    });
    const data = await res.json();
    if (data.short) {
      setShortUrl(window.location.origin + '/' + data.short);
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>Link Shortener</h1>
      <input
        type="text"
        placeholder="Enter URL"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        style={{ padding: '8px', width: '300px' }}
      />
      <button onClick={createShortLink} style={{ padding: '8px 12px', marginLeft: '10px' }}>
        Shorten
      </button>
      {shortUrl && (
        <p>Short URL: <a href={shortUrl}>{shortUrl}</a></p>
      )}
    </div>
  );
}
